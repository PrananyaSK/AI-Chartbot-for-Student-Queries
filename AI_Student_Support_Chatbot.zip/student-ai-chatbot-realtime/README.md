# AI Student Support Chatbot - Real-Time Version

Run:
1. `.venv\Scripts\activate`
2. `python training\train_model.py`
3. `uvicorn backend.main:app --reload`
4. Open `http://127.0.0.1:8000/`

Only one server is needed.

To update the chatbot's knowledge, edit `dataset/student_faq.csv`, retrain the model, and restart the server. Replace the generic sample answers with your college's verified information before submission.

For truly live admin updates without retraining, the next upgrade can move college facts into SQLite and add an admin dashboard.
