const chat = document.getElementById("chat");
const form = document.getElementById("chatForm");
const input = document.getElementById("message");

function addMessage(text, who, meta="") {
  const box = document.createElement("div");
  box.className = `msg ${who}`;
  box.textContent = text;
  if (meta) {
    const m = document.createElement("div");
    m.className = "meta";
    m.textContent = meta;
    box.appendChild(m);
  }
  chat.appendChild(box);
  chat.scrollTop = chat.scrollHeight;
}

async function ask(message) {
  input.value = message;
  await sendMessage();
}

async function sendMessage() {
  const message = input.value.trim();
  if (!message) return;
  addMessage(message, "user");
  input.value = "";

  try {
    const res = await fetch("/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({message})
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Request failed");

    const confidence = data.confidence !== undefined
      ? `Intent: ${data.intent} • Confidence: ${(data.confidence * 100).toFixed(1)}%`
      : "";

    addMessage(data.response || "No response available.", "bot", confidence);
  } catch (err) {
    addMessage("Sorry, the chatbot could not process your request.", "bot", err.message);
  }
}

form.addEventListener("submit", e => {
  e.preventDefault();
  sendMessage();
});

addMessage("Hello! I can help with admissions, courses, fees, internships, placements, contact information, and college location.", "bot");
