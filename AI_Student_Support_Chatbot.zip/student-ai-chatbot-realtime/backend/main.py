
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from backend.chatbot import get_response, get_supported_intents

app = FastAPI(
    title="AI Student Support Chatbot",
    description="Real-time NLP chatbot for student queries",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"

class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=1000)

@app.get("/")
def root():
    return FileResponse(FRONTEND_DIR / "index.html")

@app.get("/style.css")
def style():
    return FileResponse(FRONTEND_DIR / "style.css", media_type="text/css")

@app.get("/script.js")
def script():
    return FileResponse(FRONTEND_DIR / "script.js", media_type="application/javascript")

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.get("/intents")
def intents():
    return {"intents": get_supported_intents()}

@app.post("/chat")
def chat(request: ChatRequest):
    try:
        return get_response(request.message)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Chatbot error: {exc}") from exc
