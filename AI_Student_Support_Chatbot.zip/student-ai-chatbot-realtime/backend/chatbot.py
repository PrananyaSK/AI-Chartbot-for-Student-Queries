
from pathlib import Path
import joblib
import pandas as pd

BASE = Path(__file__).resolve().parent.parent
MODEL_PATH = BASE / "model" / "intent_classifier.joblib"
DATA_PATH = BASE / "dataset" / "student_faq.csv"

_model = None
_responses = {}

def _load():
    global _model, _responses
    if _model is None:
        if not MODEL_PATH.exists():
            raise FileNotFoundError("Model not found. Run: python training\\train_model.py")
        _model = joblib.load(MODEL_PATH)
        faq = pd.read_csv(DATA_PATH)
        _responses = faq.groupby("intent")["response"].first().to_dict()

def get_supported_intents():
    _load()
    return sorted(_responses.keys())

def get_response(message: str):
    _load()
    text = message.strip()
    if not text:
        return {"response": "Please enter a question.", "intent": "unknown", "confidence": 0.0}

    probabilities = _model.predict_proba([text])[0]
    classes = _model.classes_
    idx = probabilities.argmax()
    intent = classes[idx]
    confidence = float(probabilities[idx])

    if confidence < 0.38:
        return {
            "response": (
                "I'm not confident that I understood that question. "
                "Please ask about admissions, courses, fees, internships, "
                "placements, contact information, or college location."
            ),
            "intent": "unknown",
            "confidence": round(confidence, 4)
        }

    return {
        "response": _responses.get(intent, "Please try rephrasing your question."),
        "intent": intent,
        "confidence": round(confidence, 4)
    }
