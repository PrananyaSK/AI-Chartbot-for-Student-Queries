
from pathlib import Path
import json
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "dataset" / "student_faq.csv"
MODEL_DIR = BASE / "model"
MODEL_DIR.mkdir(exist_ok=True)

df = pd.read_csv(DATA)
X = df["question"].astype(str)
y = df["intent"].astype(str)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

features = FeatureUnion([
    ("word", TfidfVectorizer(lowercase=True, ngram_range=(1,2), sublinear_tf=True)),
    ("char", TfidfVectorizer(analyzer="char_wb", ngram_range=(3,5), sublinear_tf=True))
])

model = Pipeline([
    ("features", features),
    ("classifier", LogisticRegression(max_iter=5000, C=3.0, class_weight="balanced"))
])

model.fit(X_train, y_train)
pred = model.predict(X_test)
acc = accuracy_score(y_test, pred)

print(f"Accuracy: {acc:.4f} ({acc*100:.2f}%)")
print(classification_report(y_test, pred, zero_division=0))

joblib.dump(model, MODEL_DIR / "intent_classifier.joblib")
(MODEL_DIR / "metrics.json").write_text(json.dumps({
    "accuracy": float(acc),
    "train_samples": len(X_train),
    "test_samples": len(X_test),
    "classes": sorted(y.unique().tolist())
}, indent=2), encoding="utf-8")
print("Model saved successfully.")
